
const filter = document.querySelector('#input_text');
const table = document.querySelector('#table');
const tr = table.querySelectorAll('tr');
console.log(tr);
// const td = document.querySelector('td');

filter.addEventListener("keyup", search)

function search() {
    const filter_value = filter.value.toUpperCase();
    for ( var i = 0; i <tr.length; i++){
        let td = tr[i].querySelectorAll("td")[0];

        if(td){
            let text = td.textContent || td.innerText;
            if(text.toUpperCase().indexOf(filter_value) > -1){
                tr[i].style.display = "";
            }else(
                tr[i].style.display = "none"
            )
        }
    }
    
}